# StarRocks Arrow Flight connector — design & status

## TL;DR

| Goal | Route | Status |
|---|---|---|
| Query the Flight SQL server from StarRocks **today** | **JDBC external catalog** + Arrow Flight SQL JDBC driver — no StarRocks code changes | ✅ ready — `jdbc-catalog/` |
| A **native `arrow_flight` catalog** with per-endpoint parallel reads | patch FE (`ConnectorType` enum) + new FE ScanNode + **new BE C++ scanner** + Thrift | 🟡 FE metadata side written (`src/starrocks/java/…`); BE scanner not started |

## Why there is no drop-in plugin

Unlike Trino, **StarRocks has no connector plugin SPI**. `com.starrocks.connector.ConnectorFactory`
does not use `ServiceLoader`; it resolves the connector class from a hardcoded enum:

```
com.starrocks.connector.ConnectorType   // ES, HIVE, ICEBERG, JDBC, HUDI, DELTALAKE, PAIMON, ODPS, KUDU, FLUSS, UNIFIED, …
```

Adding a type means editing that enum and rebuilding the Frontend. And the part that
actually reads data lives in the **Backend (C++)** — the FE only produces scan ranges.

## What a native connector needs

1. **FE (Java)** — done here, compiles against `com.starrocks:fe-core` with `-Pstarrocks`:
   * `ArrowFlightConnector implements com.starrocks.connector.Connector` — reads catalog
     `PROPERTIES`, owns one `FlightSqlSession` (from `arrow-flight-common`).
   * `ArrowFlightMetadata implements com.starrocks.connector.ConnectorMetadata` —
     `listDbNames` → `listSchemas`, `listTableNames` → `listTables`,
     `resolveColumns` maps the Arrow result schema to `com.starrocks.catalog.Type`.
   * `patch/ConnectorType.java.patch` registers `ARROW_FLIGHT("arrow_flight", …)`.
2. **FE (Java)** — *not done*: an `ArrowFlightTable extends com.starrocks.catalog.Table`
   and an `ArrowFlightScanNode` that emits one `TScanRangeLocations` per Flight endpoint,
   each carrying the opaque ticket bytes + node locations. `FlightScanPlanner`
   (`src/main/java/…`, engine-neutral, compiles today) already produces exactly that data.
3. **Thrift** — *not done*: a `TArrowFlightScanRange { binary ticket; list<string> locations; }`
   message and a `TArrowFlightScanNode`, wired through `PlanNode`.
4. **BE (C++)** — *not done, the bulk of the work*: a `ArrowFlightScanner` on the scan
   path that connects with Arrow Flight C++, calls `DoGet(ticket)`, and feeds the
   resulting `arrow::RecordBatch`es into a StarRocks `Chunk`. Cheapest shortcut: reuse
   the existing **JDBC scanner bridge** in the BE with the Arrow Flight SQL JDBC driver
   instead of a bespoke native reader.

Pushdown (projection + `WHERE`) is rendered by `FlightScanPlanner` (DuckDB dialect, same
limits as the Trino side: no server-side `ORDER BY` / `LIMIT`).

## Files

```
starrocks-arrow-flight/
├── src/main/java/…/FlightScanPlanner.java     engine-neutral scan planner (compiles in the default build)
├── src/starrocks/java/com/starrocks/connector/arrowflight/
│   ├── ArrowFlightConnector.java              FE connector      (only with -Pstarrocks)
│   └── ArrowFlightMetadata.java               FE metadata bridge (only with -Pstarrocks)
├── patch/ConnectorType.java.patch             enum registration + how-to
├── jdbc-catalog/                              the works-today JDBC route
└── DESIGN.md
```

## Build

```bash
# engine-neutral part only (default reactor excludes this module):
mvn -f starrocks-arrow-flight/pom.xml package

# with the FE-side classes — needs com.starrocks:fe-core in ~/.m2 (build StarRocks first):
mvn -f starrocks-arrow-flight/pom.xml -Pstarrocks package
```
